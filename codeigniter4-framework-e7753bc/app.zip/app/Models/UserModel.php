<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $allowedFields    = ['username', 'email', 'password'];
    protected $useTimestamps    = false;

    protected $beforeInsert = ['hashPassword'];
    protected $beforeUpdate = ['hashPassword'];

    protected function hashPassword(array $data): array
    {
        if (! isset($data['data']['password'])) {
            return $data;
        }

        if (! str_starts_with($data['data']['password'], '$2y$') && ! str_starts_with($data['data']['password'], '$2a$')) {
            $data['data']['password'] = password_hash($data['data']['password'], PASSWORD_DEFAULT);
        }

        return $data;
    }

    /**
     * Find user by username (optimized: select only needed columns).
     */
    public function findByUsername(string $username): ?array
    {
        return $this->select('id, username, email, password')
            ->where('username', $username)
            ->first();
    }
}
